<!-- Legacy copy of SECURITY.md -->

Security contact and reporting guidance. See repository root for full details.
