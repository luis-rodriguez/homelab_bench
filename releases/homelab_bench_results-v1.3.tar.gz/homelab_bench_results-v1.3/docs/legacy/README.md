<!-- Legacy README moved into docs for GitHub Pages -->

{% raw %}

{{ site.github.repository_name }} README

See the repository root README for the canonical copy.

{% endraw %}
