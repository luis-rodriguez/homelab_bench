<!-- Legacy copy of RELEASE.md -->

Release notes and changelog. See the root for the canonical file.
