<!-- Legacy copy of SETUP_GUIDE.md -->

See the original in the repository root for canonical content.
