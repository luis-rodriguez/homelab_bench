<!-- Legacy copy of SECURITY_AUDIT_LOCAL.md -->

See repository root for the canonical audit files. This copy is provided for GitHub Pages.
