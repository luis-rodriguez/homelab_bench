<!-- Legacy copy of SECURITY_POLICY.md -->

Security policy moved into docs/legacy for archive and reference.
