<!-- Legacy copy of QUICK_REFERENCE.md -->

See repository root README for quick reference. This file was moved into docs/legacy for GitHub Pages.
